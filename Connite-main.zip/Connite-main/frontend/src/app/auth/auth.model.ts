export class Auth
{
    constructor(
        public login: string,
        public password: string,
    )
    {}
}
